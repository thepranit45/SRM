<?php
    // Database connection
    $conn = pg_connect("host=localhost dbname=your_db user=your_user password=your_password");

    if (!$conn) {
        die("Database connection failed.");
    }

    if(isset($_POST['rno'],$_POST['p1'],$_POST['p2'],$_POST['p3'],$_POST['p4'],$_POST['p5']))
    {
        $rno = $_POST['rno'];
        $class_name = $_POST['class_name'] ?? null;
        $p1 = (int)$_POST['p1'];
        $p2 = (int)$_POST['p2'];
        $p3 = (int)$_POST['p3'];
        $p4 = (int)$_POST['p4'];
        $p5 = (int)$_POST['p5'];

        $marks = $p1 + $p2 + $p3 + $p4 + $p5;
        $percentage = $marks / 5;

        // Validation
        if (empty($class_name) || empty($rno) || $p1 > 100 || $p2 > 100 || $p3 > 100 || $p4 > 100 || $p5 > 100 || 
            $p1 < 0 || $p2 < 0 || $p3 < 0 || $p4 < 0 || $p5 < 0) {
            
            if (empty($class_name)) echo '<p class="error">Please select class</p>';
            if (empty($rno)) echo '<p class="error">Please enter roll number</p>';
            if (preg_match("/[a-z]/i", $rno)) echo '<p class="error">Please enter a valid roll number</p>';
            if (preg_match("/[a-z]/i", $marks)) echo '<p class="error">Please enter valid marks</p>';
            if ($p1 > 100 || $p2 > 100 || $p3 > 100 || $p4 > 100 || $p5 > 100 || $p1 < 0 || $p2 < 0 || $p3 < 0 || $p4 < 0 || $p5 < 0)
                echo '<p class="error">Please enter valid marks</p>';
            exit();
        }

        // Fetch student name
        $query = "SELECT name FROM students WHERE rno = $1 AND class_name = $2";
        $result = pg_query_params($conn, $query, [$rno, $class_name]);
        $row = pg_fetch_assoc($result);

        if ($row) {
            $name = $row['name'];

            // Insert result
            $insert_query = "INSERT INTO result (name, rno, class, p1, p2, p3, p4, p5, marks, percentage) 
                             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)";
            $insert_result = pg_query_params($conn, $insert_query, [$name, $rno, $class_name, $p1, $p2, $p3, $p4, $p5, $marks, $percentage]);

            if (!$insert_result) {
                echo '<script>alert("Invalid Details");</script>';
            } else {
                echo '<script>alert("Successful");</script>';
            }
        } else {
            echo '<script>alert("Student not found");</script>';
        }
    }
?>

