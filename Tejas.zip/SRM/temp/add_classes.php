<?php 
	include('init.php');
    include('session.php');

    if (isset($_POST['class_name'], $_POST['class_id'])) {
        $name = $_POST["class_name"];
        $id = $_POST["class_id"];

        // Validation
        if (empty($name) || empty($id) || preg_match("/[a-z]/i", $id)) {
            if(empty($name))
                echo '<p class="error">Please enter class name</p>';
            if(empty($id))
                echo '<p class="error">Please enter class ID</p>';
            if(preg_match("/[a-z]/i", $id))
                echo '<p class="error">Please enter a valid numeric class ID</p>';
            exit();
        }

        try {
            // PostgreSQL connection
            $sql = "INSERT INTO class (id, name) VALUES (:id, :name)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute(['id' => $id, 'name' => $name]);

            echo '<script language="javascript">';
            echo 'alert("Class added successfully!")';
            echo '</script>';
        } catch (PDOException $e) {
            echo '<script language="javascript">';
            echo 'alert("Error: ' . $e->getMessage() . '")';
            echo '</script>';
        }
    }
?>

