<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="./css/home.css">
    <link rel="stylesheet" type="text/css" href="./css/form.css" media="all">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="./css/font-awesome-4.7.0/css/font-awesome.css">
    <title>Add Students</title>
</head>
<body>
        
    <div class="title">
        <a href="dashboard.php"><img src="./images/logo1.png" alt="" class="logo"></a>
        <span class="heading">Dashboard</span>
        <a href="logout.php" style="color: white"><span class="fa fa-sign-out fa-2x">Logout</span></a>
    </div>

    <div class="nav">
        <ul>
            <li class="dropdown" onclick="toggleDisplay('1')">
                <a href="#" class="dropbtn">Classes &nbsp
                    <span class="fa fa-angle-down"></span>
                </a>
                <div class="dropdown-content" id="1">
                    <a href="add_classes.php">Add Class</a>
                    <a href="manage_classes.php">Manage Class</a>
                </div>
            </li>
            <li class="dropdown" onclick="toggleDisplay('2')">
                <a href="#" class="dropbtn">Students &nbsp
                    <span class="fa fa-angle-down"></span>
                </a>
                <div class="dropdown-content" id="2">
                    <a href="add_students.php">Add Students</a>
                    <a href="manage_students.php">Manage Students</a>
                </div>
            </li>
            <li class="dropdown" onclick="toggleDisplay('3')">
                <a href="#" class="dropbtn">Results &nbsp
                    <span class="fa fa-angle-down"></span>
                </a>
                <div class="dropdown-content" id="3">
                    <a href="add_results.php">Add Results</a>
                    <a href="manage_results.php">Manage Results</a>
                </div>
            </li>
        </ul>
    </div>

    <div class="main">
        <form action="" method="post">
            <fieldset>
                <legend>Add Student</legend>
                <input type="text" name="student_name" placeholder="Student Name">
                <input type="text" name="roll_no" placeholder="Roll No">
                <?php
                    include('init.php'); // Database connection
                    include('session.php');

                    // Fetch classes from database
                    $class_result = pg_query($conn, "SELECT name FROM class");
                    
                    echo '<select name="class_name">';
                    echo '<option selected disabled>Select Class</option>';
                    while ($row = pg_fetch_assoc($class_result)) {
                        echo '<option value="'.$row['name'].'">'.$row['name'].'</option>';
                    }
                    echo '</select>';
                ?>
                <input type="submit" value="Submit">
            </fieldset>
        </form>
    </div>

    <div class="footer">
        <!-- <span>&copy Designed & Coded By Jibin Thomas</span> -->
    </div>
</body>
</html>

<?php
    if (isset($_POST['student_name'], $_POST['roll_no'])) {
        $name = $_POST['student_name'];
        $rno = $_POST['roll_no'];
        $class_name = $_POST['class_name'] ?? null;

        // Validation
        if (empty($name) || empty($rno) || empty($class_name) || 
            preg_match("/[a-z]/i", $rno) || 
            !preg_match("/^[a-zA-Z ]*$/", $name)) {
            
            if (empty($name)) echo '<p class="error">Please enter name</p>';
            if (empty($class_name)) echo '<p class="error">Please select your class</p>';
            if (empty($rno)) echo '<p class="error">Please enter your roll number</p>';
            if (preg_match("/[a-z]/i", $rno)) echo '<p class="error">Please enter a valid roll number</p>';
            if (!preg_match("/^[a-zA-Z ]*$/", $name)) echo '<p class="error">No numbers or symbols allowed in name</p>';
            
            exit();
        }

        // Insert student into database (Using Prepared Statements)
        $sql = "INSERT INTO students (name, rno, class_name) VALUES ($1, $2, $3)";
        $result = pg_query_params($conn, $sql, [$name, $rno, $class_name]);

        if (!$result) {
            echo '<script>alert("Invalid Details");</script>';
        } else {
            echo '<script>alert("Successful");</script>';
        }
    }
?>

