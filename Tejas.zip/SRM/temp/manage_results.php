<?php
    include('init.php');
    include('session.php');

    if(isset($_POST['class_name'], $_POST['rno'])) {
        $class_name = $_POST['class_name'];
        $rno = $_POST['rno'];
        echo $class_name;
        echo $rno;

        $delete_sql = pg_query($conn, "DELETE FROM result WHERE rno = '$rno' AND class = '$class_name'");
        
        if(!$delete_sql){
            echo '<script>alert("Not available");</script>';
        } else {
            echo '<script>alert("Deleted");</script>';
        }
    }

    if(isset($_POST['rn'], $_POST['p1'], $_POST['p2'], $_POST['p3'], $_POST['p4'], $_POST['p5'], $_POST['class'])) {
        $rno = $_POST['rn'];
        $class_name = $_POST['class'];
        $p1 = (int)$_POST['p1'];
        $p2 = (int)$_POST['p2'];
        $p3 = (int)$_POST['p3'];
        $p4 = (int)$_POST['p4'];
        $p5 = (int)$_POST['p5'];

        $marks = $p1 + $p2 + $p3 + $p4 + $p5;
        $percentage = $marks / 5;
        
        $sql = "UPDATE result SET p1 = '$p1', p2 = '$p2', p3 = '$p3', p4 = '$p4', p5 = '$p5', marks = '$marks', percentage = '$percentage' WHERE rno = '$rno' AND class = '$class_name'";
        
        $update_sql = pg_query($conn, $sql);
        
        if(!$update_sql){
            echo '<script>alert("Invalid Details");</script>';
        } else {
            echo '<script>alert("Updated");</script>';
        }
    }
?>

