<?php
$servername = "localhost";
$username = "postgres";  // Replace with your actual PostgreSQL username
$password = "";  // Replace with your actual PostgreSQL password
$dbname = "srms";  // Ensure this database exists

try {
    $conn = new PDO("pgsql:host=$servername;port=5432;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected successfully";  // Add this to check if connection works
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

?>

