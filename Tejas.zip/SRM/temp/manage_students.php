<?php
    include('init.php');
    include('session.php');

    $sql = "SELECT name, rno, class_name FROM students";
    $result = pg_query($conn, $sql);

    if (pg_num_rows($result) > 0) {
        echo "<table>
        <caption>Manage Students</caption>
        <tr>
        <th>NAME</th>
        <th>ROLL NO</th>
        <th>CLASS</th>
        </tr>";

        while ($row = pg_fetch_array($result)) {
            echo "<tr>";
            echo "<td>" . $row['name'] . "</td>";
            echo "<td>" . $row['rno'] . "</td>";
            echo "<td>" . $row['class_name'] . "</td>";
            echo "</tr>";
        }

        echo "</table>";
    } else {
        echo "0 Students";
    }
?>

