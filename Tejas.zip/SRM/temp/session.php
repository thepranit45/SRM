<?php
   include('init.php');
   session_start();

   // Get the logged-in user
   $user_check = $_SESSION['login_user'];

   // Query the database to check if the user exists
   $ses_sql = pg_query($conn, "SELECT userid FROM admin_login WHERE userid = '$user_check'");
   $row = pg_fetch_array($ses_sql);

   // Store the user session
   $login_session = $row['userid'];

   // If no valid session, redirect to login page
   if (!isset($_SESSION['login_user'])) {
      header("Location: login.php");
      exit(); // Ensure script stops execution after redirection
   }
?>

