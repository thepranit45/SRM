<?php
   session_start();
   
   // Unset all session variables
   session_unset();
   
   // Destroy the session
   session_destroy();

   echo '<script language="javascript">';
   echo 'alert("Logout successful");';
   echo 'window.location.href="login.php";';
   echo '</script>';
   exit();
?>

