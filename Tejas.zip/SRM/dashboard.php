<?php
// Database connection
$host = "localhost";
$port = "5432";
$dbname = "srms";
$user = "postgres";
$password = "9970";

// Create connection
$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

// Check connection
if (!$conn) {
    die("Connection failed: " . pg_last_error());
}

// Fetch total number of students
$total_students_query = "SELECT COUNT(*) AS total_students FROM students";
$total_students_result = pg_query($conn, $total_students_query);
$total_students = pg_fetch_assoc($total_students_result)['total_students'];

// Fetch total number of results
$total_results_query = "SELECT COUNT(*) AS total_results FROM results";
$total_results_result = pg_query($conn, $total_results_query);
$total_results = pg_fetch_assoc($total_results_result)['total_results'];

// Fetch recent actions (e.g., last 5 added students)
$recent_students_query = "SELECT id, name FROM students ORDER BY id DESC LIMIT 5";
$recent_students_result = pg_query($conn, $recent_students_query);

// Fetch recent actions (e.g., last 5 added results)
$recent_results_query = "SELECT r.id, s.name AS student_name FROM results r JOIN students s ON r.student_id = s.id ORDER BY r.id DESC LIMIT 5";
$recent_results_result = pg_query($conn, $recent_results_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Student Result Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
        }

        .sidebar {
            width: 250px;
            background-color: #2c3e50;
            color: white;
            height: 100vh;
            padding: 20px;
            box-sizing: border-box;
        }

        .sidebar h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar ul li {
            margin: 15px 0;
        }

        .sidebar ul li a {
            color: white;
            text-decoration: none;
            font-size: 18px;
            display: block;
            padding: 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .sidebar ul li a:hover {
            background-color: #34495e;
        }

        .main-content {
            flex-grow: 1;
            padding: 20px;
            background-color: #ecf0f1;
        }

        .header {
            background-color: #3498db;
            color: white;
            padding: 15px;
            text-align: center;
            font-size: 24px;
            margin-bottom: 20px;
        }

        .card {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .card h3 {
            margin-top: 0;
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <h2>Admin Panel</h2>
        <ul>
            <li><a href="#">Dashboard</a></li>
            <li><a href="manage_students.php">Manage Students</a></li>
            <li><a href="manage_results.php">Manage Results</a></li>
            <li><a href="add_student.php">Add New Student</a></li>
            <li><a href="add_result.php">Add New Result</a></li>
            <li><a href="view_reports.php">View Reports</a></li>
            <li><a href="settings.php">Settings</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="header">
            Welcome to the Student Result Management System
        </div>

        <div class="card">
            <h3>Quick Stats</h3>
            <p>Total Students: <?php echo $total_students; ?></p>
            <p>Total Results: <?php echo $total_results; ?></p>
            <p>Recent Activity: 5 new results added</p>
        </div>

        <div class="card">
            <h3>Recent Students Added</h3>
            <ul>
                <?php
                while ($row = pg_fetch_assoc($recent_students_result)) {
                    echo "<li>Added student: {$row['name']} (ID: {$row['id']})</li>";
                }
                ?>
            </ul>
        </div>

        <div class="card">
            <h3>Recent Results Added</h3>
            <ul>
                <?php
                while ($row = pg_fetch_assoc($recent_results_result)) {
                    echo "<li>Added result for: {$row['student_name']} (Result ID: {$row['id']})</li>";
                }
                ?>
            </ul>
        </div>
    </div>

</body>
</html>
