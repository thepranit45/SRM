<?php
session_start();

// Redirect if not logged in
if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam Results</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 90%;
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .header {
            text-align: center;
            padding: 10px;
            background-color: #8B0000;
            color: white;
            font-size: 24px;
            font-weight: bold;
        }
        .search-section {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        .search-section input, .search-section button {
            padding: 10px;
            font-size: 16px;
        }
        .student-info {
            margin-bottom: 20px;
            font-size: 18px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: white;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }
        th {
            background-color: #8B0000;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .pass {
            color: green;
            font-weight: bold;
        }
        .fail {
            color: red;
            font-weight: bold;
        }
        .print-button {
            display: flex;
            justify-content: right;
            margin-top: 20px;
        }
        .print-button button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #8B0000;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .print-button button:hover {
            background-color: #600000;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">Exam Results</div>

        <!-- Search Bar -->
        <div class="search-section">
            <input type="text" id="search_student_id" placeholder="Enter Student ID">
            <button onclick="fetchResults()">Search</button>
        </div>

        <!-- Student Info -->
        <div class="student-info">
            <p><strong>Name:</strong> <span id="student_name"></span></p>
            <p><strong>Class:</strong> <span id="student_class"></span></p>
        </div>

        <!-- Results Table -->
        <table>
            <thead>
                <tr>
                    <th>Subject</th>
                    <th>Marks Obtained</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody id="results_table">
                <tr>
                    <td colspan="3">Enter student ID and search...</td>
                </tr>
            </tbody>
        </table>

        <!-- Print Button -->
        <div class="print-button">
            <button onclick="printPage()">Print</button>
        </div>
    </div>

    <script>
        function fetchResults() {
            let studentID = $("#search_student_id").val();
            if (studentID === "") {
                alert("Please enter a student ID");
                return;
            }

            $.ajax({
                url: "fetch_results.php",
                method: "GET",
                data: { student_id: studentID },
                dataType: "json",
                success: function(response) {
                    if (response.error) {
                        $("#results_table").html(`<tr><td colspan="3">${response.error}</td></tr>`);
                        return;
                    }

                    $("#student_name").text(response.name);
                    $("#student_class").text(response.class);

                    let subjects = Object.values(response.results);
                    let tableContent = "";
                    
                    subjects.forEach((marks, index) => {
                        let statusClass = marks >= 40 ? "pass" : "fail";
                        let statusText = marks >= 40 ? "Pass" : "Fail";

                        tableContent += `
                            <tr>
                                <td>Subject ${index + 1}</td>
                                <td>${marks}</td>
                                <td class="${statusClass}">${statusText}</td>
                            </tr>
                        `;
                    });

                    $("#results_table").html(tableContent);
                },
                error: function() {
                    $("#results_table").html(`<tr><td colspan="3">Error fetching results</td></tr>`);
                }
            });
        }

        function printPage() {
            window.print();
        }
    </script>

</body>
</html>

