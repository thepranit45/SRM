<?php
// Database connection
$host = "localhost";
$port = "5432";
$dbname = "srms";
$user = "postgres";
$password = "9970";

// Create connection
$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

// Check connection
if (!$conn) {
    die("Connection failed: " . pg_last_error());
}

// Fetch all students for the dropdown
$students_query = "SELECT id, name FROM students";
$students_result = pg_query($conn, $students_query);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $student_id = $_POST['student_id'];
    $subject1 = $_POST['subject1'];
    $subject2 = $_POST['subject2'];
    $subject3 = $_POST['subject3'];
    $subject4 = $_POST['subject4'];
    $subject5 = $_POST['subject5'];
    $subject6 = $_POST['subject6'];
    $subject7 = $_POST['subject7'];
    $subject8 = $_POST['subject8'];

    // Insert data into the database
    $query = "INSERT INTO results (
                student_id, subject1, subject2, subject3, subject4,
                subject5, subject6, subject7, subject8
              ) VALUES (
                $student_id, $subject1, $subject2, $subject3, $subject4,
                $subject5, $subject6, $subject7, $subject8
              )";
    $result = pg_query($conn, $query);

    if ($result) {
        echo "<p style='color: green; text-align: center;'>Result added successfully!</p>";
    } else {
        echo "<p style='color: red; text-align: center;'>Error: " . pg_last_error($conn) . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Result</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
        }
        .sidebar {
            width: 250px;
            background-color: #2c3e50;
            color: white;
            height: 100vh;
            padding: 20px;
            box-sizing: border-box;
        }
        .main-content {
            flex-grow: 1;
            padding: 20px;
            background-color: #ecf0f1;
        }
        .form-container {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-container input, .form-container select {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .form-container button {
            background-color: #3498db;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h2>Admin Panel</h2>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="manage_students.php">Manage Students</a></li>
            <li><a href="manage_results.php">Manage Results</a></li>
            <li><a href="add_student.php">Add New Student</a></li>
            <li><a href="add_result.php">Add New Result</a></li>
            <li><a href="view_reports.php">View Reports</a></li>
            <li><a href="settings.php">Settings</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <h2>Add New Result</h2>
        <div class="form-container">
            <form method="POST" action="add_result.php">
                <!-- Student Selection Dropdown -->
                <label for="student_id">Select Student:</label>
                <select name="student_id" id="student_id" required>
                    <option value="" selected disabled>-- Select a Student --</option>
                    <?php
                    while ($row = pg_fetch_assoc($students_result)) {
                        echo "<option value='{$row['id']}'>{$row['name']}</option>";
                    }
                    ?>
                </select>

                <!-- Subject Marks -->
                <label for="subject1">Subject 1 Marks:</label>
                <input type="number" name="subject1" placeholder="Enter marks for Subject 1" min="0" max="100" required>

                <label for="subject2">Subject 2 Marks:</label>
                <input type="number" name="subject2" placeholder="Enter marks for Subject 2" min="0" max="100" required>

                <label for="subject3">Subject 3 Marks:</label>
                <input type="number" name="subject3" placeholder="Enter marks for Subject 3" min="0" max="100" required>

                <label for="subject4">Subject 4 Marks:</label>
                <input type="number" name="subject4" placeholder="Enter marks for Subject 4" min="0" max="100" required>

                <label for="subject5">Subject 5 Marks:</label>
                <input type="number" name="subject5" placeholder="Enter marks for Subject 5" min="0" max="100" required>

                <label for="subject6">Subject 6 Marks:</label>
                <input type="number" name="subject6" placeholder="Enter marks for Subject 6" min="0" max="100" required>

                <label for="subject7">Subject 7 Marks:</label>
                <input type="number" name="subject7" placeholder="Enter marks for Subject 7" min="0" max="100" required>

                <label for="subject8">Subject 8 Marks:</label>
                <input type="number" name="subject8" placeholder="Enter marks for Subject 8" min="0" max="100" required>

                <!-- Submit Button -->
                <button type="submit">Add Result</button>
            </form>
        </div>
    </div>
</body>
</html>
