<?php
session_start();
include("db_connect.php");

// Admin login
if (isset($_POST["admin_userid"], $_POST["admin_password"])) {
    $username = $_POST["admin_userid"];
    $password = $_POST["admin_password"];

    $stmt = $conn->prepare("SELECT userid FROM admin_login WHERE userid = :username AND password = :password");
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $password);
    $stmt->execute();

    if ($stmt->rowCount() == 1) {
        $_SESSION['login_user'] = $username;
        $_SESSION['role'] = 'admin';
        header("Location: dashboard.php");
        exit();
    } else {
        echo '<script>alert("Invalid Username or Password for Admin");</script>';
    }
}

// Student login
if (isset($_POST["student_rollno"])) {
    $rollno = $_POST["student_rollno"];

    $stmt = $conn->prepare("SELECT * FROM students WHERE rollno = :rollno");
    $stmt->bindParam(':rollno', $rollno);
    $stmt->execute();

    if ($stmt->rowCount() == 1) {
        $student = $stmt->fetch(PDO::FETCH_ASSOC);
        $_SESSION['student_id'] = $student['id'];
        $_SESSION['student_name'] = $student['name'];
        $_SESSION['student_class'] = $student['class'];
        header("Location: student_result.php");
        exit();
    } else {
        echo '<script>alert("Invalid Roll No");</script>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <div class="title">Student Result Management System</div>

    <div class="main">
        <div class="login">
            <form action="login.php" method="post">
                <fieldset>
                    <legend>Admin Login</legend>
                    <input type="text" name="admin_userid" placeholder="Admin User ID" required>
                    <input type="password" name="admin_password" placeholder="Password" required>
                    <input type="submit" value="Login">
                </fieldset>
            </form>    
        </div>

        <div class="search">
            <form action="login.php" method="post">
                <fieldset>
                    <legend>Student Login</legend>
                    <input type="text" name="student_rollno" placeholder="Roll No" required>
                    <input type="submit" value="View Result">
                </fieldset>
            </form>
        </div>
    </div>
</body>
</html>

