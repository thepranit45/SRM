<?php
session_start();

// Database connection
$servername = "localhost";
$username = "postgres";
$password = "9970";
$dbname = "srms";

try {
    $conn = new PDO("pgsql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Handle admin login form submission
if (isset($_POST["admin_userid"], $_POST["admin_password"])) {
    $username = $_POST["admin_userid"];
    $password = $_POST["admin_password"];

    // Admin login logic
    $stmt = $conn->prepare("SELECT userid FROM admin_login WHERE userid = :username AND password = :password");
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $password);
    $stmt->execute();

    if ($stmt->rowCount() == 1) {
        $_SESSION['login_user'] = $username;
        $_SESSION['role'] = 'admin';
        header("Location: dashboard.php");
        exit();
    } else {
        echo '<script language="javascript">';
        echo 'alert("Invalid Username or Password for Admin")';
        echo '</script>';
    }
}

// Handle student login form submission
if (isset($_POST["student_email"], $_POST["student_class"])) {
    $email = $_POST["student_email"];
    $class = $_POST["student_class"];

    // Student login logic
    $stmt = $conn->prepare("SELECT email FROM students WHERE email = :email AND class = :class");
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':class', $class);
    $stmt->execute();

    if ($stmt->rowCount() == 1) {
        $_SESSION['login_user'] = $email;
        $_SESSION['role'] = 'student';
        header("Location: student_dashboard.php");
        exit();
    } else {
        echo '<script language="javascript">';
        echo 'alert("Invalid Email or Class for Student")';
        echo '</script>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="./font-awesome-4.7.0/css/font-awesome.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
</head>
<body>
    <div class="title">
        <span>Student Result Management System</span>
    </div>

    <div class="main">
        <!-- Admin Login Section -->
        <div class="login">
            <form action="login.php" method="post" name="admin_login">
                <fieldset>
                    <legend class="heading">Admin Login</legend>
                    <input type="text" name="admin_userid" placeholder="Admin User ID" autocomplete="off" required>
                    <input type="password" name="admin_password" placeholder="Password" autocomplete="off" required>
                    <input type="submit" value="Login">
                </fieldset>
            </form>    
        </div>

        <!-- Student Login Section -->
        <div class="search">
            <form action="login.php" method="post" name="student_login">
                <fieldset>
                    <legend class="heading">Student Login</legend>
                    <input type="email" name="student_email" placeholder="Email" autocomplete="off" required>

                    <?php
                        $stmt = $conn->query("SELECT name FROM class");
                        echo '<select name="student_class" required>';
                        echo '<option value="" selected disabled>Select Class</option>';
                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                            echo '<option value="'.$row['name'].'">'.$row['name'].'</option>';
                        }
                        echo '</select>';
                    ?>

                    <input type="submit" value="Login">
                </fieldset>
            </form>
        </div>
    </div>
</body>
</html>
