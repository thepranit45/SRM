<?php
session_start();

// Check if student is logged in
if (!isset($_SESSION['student_id'])) {
    echo json_encode(['error' => 'Unauthorized access']);
    exit();
}

// Database connection
$servername = "localhost";
$username = "postgres";
$password = "9970";
$dbname = "srms";

try {
    $conn = new PDO("pgsql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['error' => 'Database connection failed']);
    exit();
}

// Get student details
$student_id = $_SESSION['student_id'];
$student_name = $_SESSION['student_name'];
$student_class = $_SESSION['student_class'];

// Define subject columns
$subject_columns = ['subject1', 'subject2', 'subject3', 'subject4', 'subject5', 'subject6', 'subject7', 'subject8'];

// Fetch results
$query = "SELECT " . implode(", ", $subject_columns) . " FROM results WHERE student_id = :student_id";
$stmt = $conn->prepare($query);
$stmt->bindParam(':student_id', $student_id);
$stmt->execute();
$results = $stmt->fetch(PDO::FETCH_ASSOC);

// Prepare JSON response
if ($results) {
    echo json_encode([
        'name' => $student_name,
        'class' => $student_class,
        'results' => $results
    ]);
} else {
    echo json_encode(['error' => 'No results found']);
}
?>

