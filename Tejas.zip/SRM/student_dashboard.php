<?php
session_start();

// Debug: Check if student is logged in
if (!isset($_SESSION['student_id'])) {
    echo "Student not logged in. Redirecting to login page...";
    header("Location: login.php");
    exit();
}

// Database connection parameters
$host = "localhost";
$port = "5432";
$dbname = "srms";
$user = "postgres";
$password = "9970";

// Create connection
$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

// Check connection
if (!$conn) {
    die("Connection failed: " . pg_last_error());
}

// Fetch student details
$student_id = $_SESSION['student_id'];
$query = "SELECT * FROM students WHERE id = $1";
$result = pg_query_params($conn, $query, array($student_id));

if (!$result) {
    die("Query failed: " . pg_last_error($conn));
}

if (pg_num_rows($result) == 1) {
    $student = pg_fetch_assoc($result);

    // Debug: Print student details
    echo "Student Details:<br>";
    print_r($student);
} else {
    die("Student not found.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .header {
            background-color: #3498db;
            color: white;
            padding: 15px;
            text-align: center;
            font-size: 24px;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .profile, .actions {
            margin-bottom: 20px;
        }
        .profile h2, .actions h2 {
            margin-top: 0;
        }
        .profile p {
            margin: 5px 0;
        }
        .actions a {
            display: inline-block;
            margin-right: 10px;
            padding: 10px 20px;
            background-color: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        .actions a:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
    <div class="header">
        Welcome to the Student Panel
    </div>

    <div class="container">
        <!-- Student Profile -->
        <div class="profile">
            <h2>Your Profile</h2>
            <p><strong>Name:</strong> <?php echo $student['name']; ?></p>
            <p><strong>Roll No:</strong> <?php echo $student['rollno']; ?></p>
            <p><strong>Class:</strong> <?php echo $student['class']; ?></p>
            <p><strong>Email:</strong> <?php echo $student['email']; ?></p>
        </div>

        <!-- Actions -->
        <div class="actions">
            <h2>Actions</h2>
            <a href="view_result.php">View Result</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
</body>
</html>
