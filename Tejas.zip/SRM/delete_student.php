<?php
// Database connection
$host = "localhost";
$port = "5432";
$dbname = "srms";
$user = "postgres";
$password = "9970";

// Create connection
$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

// Check connection
if (!$conn) {
    die("Connection failed: " . pg_last_error());
}

// Get the student ID from the URL
if (isset($_GET['id'])) {
    $student_id = $_GET['id'];

    // Begin a transaction
    pg_query($conn, "BEGIN");

    // Step 1: Delete all results associated with the student
    $delete_results_query = "DELETE FROM results WHERE student_id = $student_id";
    $delete_results_result = pg_query($conn, $delete_results_query);

    if (!$delete_results_result) {
        // Rollback the transaction if there's an error
        pg_query($conn, "ROLLBACK");
        die("Error deleting results: " . pg_last_error($conn));
    }

    // Step 2: Delete the student
    $delete_student_query = "DELETE FROM students WHERE id = $student_id";
    $delete_student_result = pg_query($conn, $delete_student_query);

    if (!$delete_student_result) {
        // Rollback the transaction if there's an error
        pg_query($conn, "ROLLBACK");
        die("Error deleting student: " . pg_last_error($conn));
    }

    // Commit the transaction if both queries succeed
    pg_query($conn, "COMMIT");

    // Redirect to the manage students page
    header("Location: manage_students.php");
    exit();
} else {
    die("Invalid request.");
}

// Close connection
pg_close($conn);
?>
