<?php
// Database connection
$host = "localhost";
$port = "5432";
$dbname = "srms";
$user = "postgres";
$password = "9970";

// Create connection
$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

// Check connection
if (!$conn) {
    die("Connection failed: " . pg_last_error());
}

// Fetch all results
$query = "SELECT r.id, s.name AS student_name, r.subject1, r.subject2, r.subject3, r.subject4,
                 r.subject5, r.subject6, r.subject7, r.subject8
          FROM results r
          JOIN students s ON r.student_id = s.id";
$result = pg_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Results</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
        }
        .sidebar {
            width: 250px;
            background-color: #2c3e50;
            color: white;
            height: 100vh;
            padding: 20px;
            box-sizing: border-box;
        }
        .main-content {
            flex-grow: 1;
            padding: 20px;
            background-color: #ecf0f1;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #3498db;
            color: white;
        }
        .action-buttons a {
            margin-right: 10px;
            text-decoration: none;
            color: #3498db;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h2>Admin Panel</h2>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="manage_students.php">Manage Students</a></li>
            <li><a href="manage_results.php">Manage Results</a></li>
            <li><a href="add_student.php">Add New Student</a></li>
            <li><a href="add_result.php">Add New Result</a></li>
            <li><a href="view_reports.php">View Reports</a></li>
            <li><a href="settings.php">Settings</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <h2>Manage Results</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Student Name</th>
                    <th>Subject 1</th>
                    <th>Subject 2</th>
                    <th>Subject 3</th>
                    <th>Subject 4</th>
                    <th>Subject 5</th>
                    <th>Subject 6</th>
                    <th>Subject 7</th>
                    <th>Subject 8</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = pg_fetch_assoc($result)) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['student_name']}</td>
                            <td>{$row['subject1']}</td>
                            <td>{$row['subject2']}</td>
                            <td>{$row['subject3']}</td>
                            <td>{$row['subject4']}</td>
                            <td>{$row['subject5']}</td>
                            <td>{$row['subject6']}</td>
                            <td>{$row['subject7']}</td>
                            <td>{$row['subject8']}</td>
                            <td class='action-buttons'>
                                <a href='edit_result.php?id={$row['id']}'>Edit</a>
                                <a href='delete_result.php?id={$row['id']}' onclick='return confirm(\"Are you sure you want to delete this result?\");'>Delete</a>
                            </td>
                          </tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
