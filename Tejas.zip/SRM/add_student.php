<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection
    $host = "localhost";
    $port = "5432";
    $dbname = "srms";
    $user = "postgres";
    $password = "9970";

    // Create connection
    $conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

    // Check connection
    if (!$conn) {
        die("Connection failed: " . pg_last_error());
    }

    // Get form data
    $name = $_POST['name'];
    $rollno = $_POST['rollno'];
    $class = $_POST['class'];
    $email = $_POST['email'];

    // Insert data into the database
    $query = "INSERT INTO students (name, rollno, class, email) VALUES ('$name', '$rollno', '$class', '$email')";
    $result = pg_query($conn, $query);

    if ($result) {
        echo "<p style='color: green; text-align: center;'>Student added successfully!</p>";
    } else {
        echo "<p style='color: red; text-align: center;'>Error: " . pg_last_error($conn) . "</p>";
    }

    // Close connection
    pg_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Student</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
        }
        .sidebar {
            width: 250px;
            background-color: #2c3e50;
            color: white;
            height: 100vh;
            padding: 20px;
            box-sizing: border-box;
        }
        .main-content {
            flex-grow: 1;
            padding: 20px;
            background-color: #ecf0f1;
        }
        .form-container {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-container input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .form-container button {
            background-color: #3498db;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h2>Admin Panel</h2>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="manage_students.php">Manage Students</a></li>
            <li><a href="manage_results.php">Manage Results</a></li>
            <li><a href="add_student.php">Add New Student</a></li>
            <li><a href="add_result.php">Add New Result</a></li>
            <li><a href="view_reports.php">View Reports</a></li>
            <li><a href="settings.php">Settings</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <h2>Add New Student</h2>
        <div class="form-container">
            <form method="POST" action="add_student.php">
                <input type="text" name="name" placeholder="Student Name" required>
                <input type="text" name="rollno" placeholder="Roll No" required>
                <input type="text" name="class" placeholder="Class" required>
                <input type="email" name="email" placeholder="Email" required>
                <button type="submit">Add Student</button>
            </form>
        </div>
    </div>
</body>
</html>
